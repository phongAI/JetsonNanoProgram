import json
import os
import numpy as np
import pickle
def writeJsonConfig(path,numCam,autoFocus,focusLength):
        configParameter = {"numCam": numCam,"autoFocus": autoFocus,"focusLength": focusLength}
        with open(path,'w') as f:
            json.dump(configParameter,f)

def readJsonConfig(path):
    if os.path.exists(path):
        with open(path,'r') as f:
            config = json.load(f)
        return config

def readFile(path):
    # Read all class
    if os.path.exists(path):
        with open(path, 'rb') as f:
            className = sorted(pickle.load(f))
        return className
