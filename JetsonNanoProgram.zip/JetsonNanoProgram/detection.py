import os
from keras import models
import cv2
import pickle
import numpy as np
import readWrite
import variable
import time

class OCR():

    @staticmethod
    def detectText(images):
        grayImage = cv2.cvtColor(images,cv2.COLOR_BGR2GRAY)

@classmethod
class ImageClassifier():
    @staticmethod
    def getModel(path):
        # Get class
        listFile = os.listdir(path)
        for file in listFile:
            if os.path.splitext(file)[1] == ".txt":
                filePath = os.path.join(path, file)
                className = readWrite.readFile(filePath)
            else:
                filePath = os.path.join(path, file)
                model = models.load_model(filePath)
        return className, model

    @staticmethod
    def detectObject(images):
        className, model = get
        beginTime = time.time()
        #Process image
        img = cv2.resize(images,dsize=(variable.input_shape[0],variable.input_shape[1]))
        img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        img = np.expand_dims(img,0)
        img = img/255.0
        index = np.argmax(model.predict(img))
        detection = className[index]
        duration = round(time.time() - beginTime,1)
        #Choose color
        np.random.seed(10)
        colorList = np.random.randint(100, 190, size=(len(className), 3))
        color = colorList[index]
        colorText = (color[0],color[1],color[2])
        return detection,colorText,duration



