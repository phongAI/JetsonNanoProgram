from PyQt5 import QtWidgets,uic,QtGui
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtMultimedia import *
from PyQt5.QtCore import *

import detection
import variable
from datetime import datetime
import readWrite,os,time,sys
from detection import *
extension = ['.bmp','.png','.jpg','.jpeg','.PNG','.BMP','.JPG','.JPEG']

# VideoCapture
vid = cv2.VideoCapture(0)
vid.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
vid.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

#GUI
class Ui(QtWidgets.QMainWindow,QWidget):
    def __init__(self):
        super(Ui,self).__init__()
        uic.loadUi(variable.mainUi,self)
        #Button Event
        self.captureButton.clicked.connect(self.captureImageEvent)
        self.loadButton.clicked.connect(self.openFileNameDialogEvent)
        self.detectButton.clicked.connect(self.detectButtonEvent)
        self.mainWindowButton.clicked.connect(self.mainWindowEvent)
        self.settingWindowButton.clicked.connect(self.settingWindowEvent)
        self.numCamBox.valueChanged.connect(self.numCamBoxEvent)
        self.autofocusBox.stateChanged.connect(self.autoFocusStateChangedEvent)
        self.focusSlider.valueChanged.connect(self.manualFocusEvent)
        self.saveButton.clicked.connect(self.saveButtonEvent)
        self.resetButton.clicked.connect(self.resetButtonEvent)
        self.ocrButton.clicked.connect(self.ocrButtonEvent)
        self.modelBox.currentTextChanged.connect(self.modelChangedEvent)

        # Set icon
        self.detectButton.setIcon(QIcon('Icon/search.svg'))
        self.ocrButton.setIcon(QIcon('Icon/type.svg'))
        self.loadButton.setIcon(QIcon('Icon/image.svg'))
        self.settingWindowButton.setIcon(QIcon('Icon/settings.svg'))
        self.captureButton.setIcon(QIcon('Icon/camera.svg'))
        self.mainWindowButton.setIcon(QIcon('Icon/home.svg'))
        self.toolButton.setIcon(QIcon('Icon/pocket.svg'))
        self.menuButton.setIcon(QIcon('Icon/menu.svg'))

        #ListWidget
        self.notifyWidget = self.findChild(QtWidgets.QListWidget,"notifyWidget")
        self.notification = "Begin new program!"
        message = self.notifyFormat(self.notification)
        self.notifyWidget.addItem(message)
        self.notifyWidget.setWordWrap(True)
        self.countLine = 0
        #Camera
        self.availabel_camera = QCameraInfo.availableCameras()
        if self.availabel_camera:
            # set parameter
            self.setCameraParameter()

        # Load Model
        self.loadAllModels()

        #Load config
        configPath = os.path.join(variable.configFolder,variable.configFileName)
        if not os.path.exists(configPath):
            self.numCam = variable.defaultNumCam
            self.autoFocus = variable.defaultAutoFocus
            self.manualFocus = variable.defaultManualFocus

        else:
            configJson = readWrite.readJsonConfig(configPath)
            self.numCam = configJson['numCam']
            self.autoFocus = configJson['autoFocus']
            self.manualFocus = configJson['focusLength']

        """Uploading setiing"""
        self.uploadSetting()

        #Current form
        self.stackedWidget.setCurrentIndex(0)
        self.mainWindowButton.setStyleSheet("background-color: rgb(128, 112, 171);")
        self.show()
        self.toolAllow = False
        self.changedModel = False

    """Button Event"""
    def saveButtonEvent(self):
        #Apply new state
        self.setCameraParameter()

        # Upload setting
        self.uploadSetting()

        #Save file
        path = os.path.join(variable.configFolder,variable.configFileName)
        readWrite.writeJsonConfig(path,numCam=self.numCam,autoFocus=self.autoFocus,focusLength=self.manualFocus)

        #Notification
        QMessageBox.about(self,"Notify!","Save setting done")
        if self.autoFocus:
            notification = f"New setting updated!\n Number of cams: {self.numCam}. Autofocus mode: On"
        else:
            notification = f"New setting updated!\n Number of cams: {self.numCam}. Autofocus mode: Off. Manual focus: {self.manualFocus}"
        self.addItemListView(notification,color="g")

    def resetButtonEvent(self):
        #Set value
        self.numCam = variable.defaultNumCam
        self.autoFocus = variable.defaultAutoFocus
        self.manualFocus = variable.defaultManualFocus

        #Upload setting
        self.uploadSetting()

        # Apply new state
        self.setCameraParameter()

        # Notification
        QMessageBox.about(self, "Notify!", "Reset setting done")

        if self.autoFocus:
            notification = f"Default setting!\n Number of cams: {self.numCam}. Autofocus mode: On"
        else:
            notification = f"Default setting!\n Number of cams: {self.numCam}. Autofocus mode: Off. Manual focus: {self.manualFocus}"
        self.addItemListView(notification,color="g")

    def mainWindowEvent(self):
        time.sleep(0.1)
        self.mainWindowButton.setStyleSheet("background-color: rgb(128, 112, 171);")
        self.settingWindowButton.setStyleSheet("background-color: rgb(70, 78, 111);")
        self.stackedWidget.setCurrentIndex(0)

    def settingWindowEvent(self):
        time.sleep(0.1)
        self.settingWindowButton.setStyleSheet("background-color: rgb(128, 112, 171);")
        self.mainWindowButton.setStyleSheet("background-color: rgb(70, 78, 111);")
        self.stackedWidget.setCurrentIndex(1)

    def numCamBoxEvent(self):
        if(int(self.numCamBox.value()) == 2):
            QMessageBox.about(self,"Error","Camera limit: 2")

    def ocrButtonEvent(self):
        if self.toolAllow:
            pass
        else:
            pass

    def modelChangedEvent(self):
        self.changedModel = True
        currentModel = self.modelBox.currentText()
        modelPath = os.path.join(variable.modelFolder,currentModel)
        if len(modelPath)>6:
            if len(os.listdir(modelPath)) == 2:
                notification = f"Load model: {currentModel} success!"
                self.addItemListView(notification,color="g")
                ImageClassifier.getModel(modelPath)
            else:
                notification = f"Load model: {currentModel} failed! Config problem"
                self.addItemListView(notification,color="r")


    def autoFocusStateChangedEvent(self):
        if self.autofocusBox.isChecked():
            self.focusSlider.setEnabled(False)
            self.autoFocus = True
        else:
            self.focusSlider.setEnabled(True)
            self.autoFocus = False

    def manualFocusEvent(self):
        self.manualFocus = self.focusSlider.value()*self.focusSlider.singleStep()
        self.focusValue.setText(str(self.manualFocus))

    """Event"""
    #Open File Dialog event
    def openFileNameDialogEvent(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        filePath,ext = QFileDialog.getOpenFileName(self,'Choose file','','Images Files (*.png | *.jpeg | *.jpg | *.bmp)',options=options)
        self.pic = cv2.imread(filePath)
        fileName = os.path.basename(filePath)
        ext = os.path.splitext(fileName)[1]
        if ext in extension:
            pixmap = QPixmap(filePath)
            self.setImage(pixmap,fileName)
        elif len(ext) == 0:
            pass
        else:
            notification = f"Extension file {ext} is not image type!"
            self.addItemListView(notification,color="r")
        self.toolAllow = True

    def captureImageEvent(self):
        #Read frame from camera
        ret,img = vid.read()
        self.pic = img
        qtImage = QtGui.QImage(img,img.shape[1],img.shape[0],img.shape[1]*3,QtGui.QImage.Format.Format_BGR888)

        #Set image to pixmap
        pixmap = QtGui.QPixmap(qtImage)
        self.displayLabel.setPixmap(pixmap)
        self.displayLabel.setAlignment(Qt.AlignCenter)

        #Save image to disk
        nowTime = datetime.now().strftime("%H-%M-%S")
        imgName = f"Images_{nowTime}.PNG"
        cv2.imwrite(f"{variable.SaveImageFolder}/{imgName}",img)

        self.toolAllow = True
        #Notify
        notification = f"Capture new image! Saving: {imgName} to /{variable.SaveImageFolder}"
        self.addItemListView(notification)
        time.sleep(0.5)

    def detectButtonEvent(self):
        if self.toolAllow & self.changedModel:
            message1 = "Predicting: ..."
            self.addItemListView(message1)
            detection,colorText,duration = ImageClassifier.detectObject(self.pic)
            self.resultLabel.setText(detection)
            self.resultLabel.setStyleSheet(f"color : rgb{colorText};")
            message2 = f"Result: {detection}. Time processing: {duration}s"
            self.addItemListView(message2)
        else:
            message2 = "Empty model!"
            self.addItemListView(message2,color="r")

    def uploadSetting(self):
        self.numCamBox.setValue(self.numCam)
        # auto Focus
        self.focusValue.setText(str(self.manualFocus))
        if self.autoFocus:
            # Set state
            self.autofocusBox.setChecked(True)
            self.focusValue.setEnabled(False)
        else:
            # Set state
            self.autofocusBox.setChecked(False)
            self.focusValue.setEnabled(True)

        self.focusSlider.setValue(int(self.manualFocus/self.focusSlider.singleStep()))

    def setCameraParameter(self):
        """Uploading setiing"""
        if self.autoFocus:
            #Set state
            vid.set(cv2.CAP_PROP_AUTOFOCUS,1)
        else:
            # Apply to came
            #vid.set(cv2.CAP_PROP_AUTOFOCUS, 0)
            vid.set(cv2.CAP_PROP_FOCUS,int(self.manualFocus))

    # Add infomation to listView
    def addItemListView(self, notification,color="w"):
        message = self.notifyFormat(notification)
        self.countLine += 1
        self.notifyWidget.addItem(message)
        if color == "g":
            self.notifyWidget.item(self.countLine).setForeground(QColor("#029D00"))
        elif color == "r":
            self.notifyWidget.item(self.countLine).setForeground(QColor("#EB0917"))
        elif color == "w":
            self.notifyWidget.item(self.countLine).setForeground(QColor("#000000"))
        self.notifyWidget.scrollToBottom()

    # Format Message Information
    def notifyFormat(self, text):
        now = datetime.now()
        time = now.strftime('%H:%M:%S')
        message = f"[{time}] - {text}"
        return message

    # Set Image Function
    def setImage(self, img, fileName):
        self.centerColumn = self.findChild(QFrame, 'centerColumn')
        """Column Dimension"""
        columnWidth, columnHeight = self.centerColumn.width(), self.centerColumn.height()
        """Image dimension"""
        imageWidth, imageHeight = img.width(), img.height()
        xFactor = int(imageWidth / columnWidth)
        yFactor = int(imageHeight / columnHeight)

        # Resize base on dimension
        if xFactor > 1:
            if xFactor > yFactor:
                img = img.scaledToWidth(columnWidth)
            else:
                img = img.scaledToHeight(columnHeight)
        self.displayLabel.setPixmap(img)
        self.displayLabel.setAlignment(Qt.AlignCenter)

        # Notification
        notification = f"Load {fileName} from disk completed! Images size is {imageWidth}x{imageHeight}"
        self.addItemListView(notification,color="g")

    def loadAllModels(self):
        files = os.listdir(variable.modelFolder)
        files.insert(0,"")
        for file in files:
            folderPath = os.path.join(variable.modelFolder,file)
            if os.path.isdir(folderPath):
                self.modelBox.addItem(file)

def main():
    #Create essential directory
    os.makedirs(variable.SaveImageFolder,exist_ok=True)
    os.makedirs(variable.configFolder, exist_ok=True)

    #GUI
    app = QtWidgets.QApplication(sys.argv)
    window = Ui()
    app.exec_()

if __name__ == "__main__":
    main()